$name = split-path (whoami) -leaf
"Hello, $name!"
